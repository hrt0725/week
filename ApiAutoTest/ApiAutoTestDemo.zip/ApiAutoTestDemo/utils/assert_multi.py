# -*- coding: utf-8 -*-
# @Time    : 2025/9/25 12:43
# @Author  : Lan
# @File    : assert_multi.py
# @Software: PyCharm
# @Description :
from typing import Literal

methodL = Literal["equal", "in", "not in", "has"]


def am(realityValue, expectValue, method: methodL):
    if method == "equal":
        assert realityValue == expectValue
    elif method == "in":
        assert expectValue in realityValue
    elif method == "not in":
        assert expectValue not in realityValue
    elif method == "has":
        assert realityValue is not None


if __name__ == '__main__':
    am(2, 1 + 1, method="equal")
    am(5, [2, 6, 5], method="in")
    am("fwf", "11fwf", method="in")
    am(7, [2, 6, 5], method="not in")
