# -*- coding: utf-8 -*-
# @Time    : 2025/9/26 10:47
# @Author  : Lan
# @File    : TestCastTemplate.py
# @Software: PyCharm
# @Description :

import ddt
import pytest
import requests

from config.config import AppKey, getDataPath
from utils.assert_multi import am
from utils.common import get_nested_value
from utils.log_utils import createLoger

@ddt.ddt()
class TestApiRegister:

    @ddt.file_data(getDataPath().joinpath("api_register.yaml"))
    def test_api_register(self, **caseData):
        loger = createLoger()
        url = "http://api.yesapi.net/api/App/User/Register"
        caseData["data"]["app_key"] = AppKey

        loger.info("开始请求({})：{}".format(caseData["method"], url))
        loger.info("请求参数：{}".format(caseData))
        if caseData["method"] == "POST":
            resultData = requests.post(url=url, params=caseData["data"]).json()
        else:
            resultData = requests.get(url=url, params=caseData["data"]).json()
        loger.info("请求结果：{}".format(resultData))
        loger.info("开始断言:")
        for item in caseData["assert_info"]:
            loger.info("{}:实际值：{}".format(item["key"], get_nested_value(resultData, item["key"])))
            loger.info("{}:期望值：{}".format(item["key"], item["expect_value"]))
            loger.info("断言方式:{}".format(item["assert_method"]))
            am(get_nested_value(resultData, item["key"]),
               item["expect_value"],
               item["assert_method"])

if __name__ == '__main__':
    pytest.main()
