# -*- coding: utf-8 -*-
# @Time    : 2025/9/26 10:45
# @Author  : Lan
# @File    : CreateTestTemplate.py
# @Software: PyCharm
# @Description :
import os

from config import config
from config.config import getDataPath, getConfigPath, getTestCasePath

if __name__ == '__main__':
    files = os.listdir(getDataPath())
    for fileName in files:
        if fileName.endswith(".yaml") or fileName.endswith(".yml"):
            baseName = fileName.replace(".yaml", "").replace("yml", "")
            caseFileName = "test_{}.py".format(baseName)
            if getTestCasePath().joinpath(caseFileName).is_file():
                continue
            caseName = baseName
            parts = baseName.split('_')
            className = parts[0] + ''.join(part.capitalize() for part in parts[1:])
            className = className[0].upper() + className[1:]
            with open(getConfigPath().joinpath("TestCastTemplate.py.txt"), "r", encoding='utf-8') as f:
                templateContent = f.read() % {
                    "className": className,
                    "yamlName": fileName,
                    "caseName": baseName,
                    "apiName": getattr(config, baseName),
                }
                print(templateContent)
                with open(getTestCasePath().joinpath(caseFileName), "w", encoding='utf-8') as writefile:
                    writefile.write(templateContent)
