# -*- coding: utf-8 -*-
# @Time    : 2025/9/25 14:53
# @Author  : Lan
# @File    : config.py
# @Software: PyCharm
# @Description :
from utils.common import getProjectPath

HostName = "http://api.yesapi.net"
AppKey = "F2402005A90D70AEB649F409C8D68D85"

api_login = HostName + "/api/App/User/Login"
api_register = HostName + "/api/App/User/Register"
api_get_last_login_user = HostName + "/api/App/User/GetLastestLoginList"
api_user_check = HostName + "/api/App/User/Check"


def getDataPath():
    return getProjectPath().joinpath("data")


def getConfigPath():
    return getProjectPath().joinpath("config")


def getLogPath():
    return getProjectPath().joinpath("log")


def getReportPath():
    return getProjectPath().joinpath("report")


def getCasePath():
    return getProjectPath().joinpath("case")


def getTestCasePath():
    return getProjectPath().joinpath("TestCase")
