# -*- coding: utf-8 -*-
# @Time    : 2025/9/24 16:46
# @Author  : Lan
# @File    : test_get_user_info.py
# @Software: PyCharm
# @Description : 
import pytest
import requests

from cases.conftest import HostName
from config.config import AppKey


class TestGetUserInfo:
    def test_get_user_info(self, login_ext):
        url = HostName + "/api/App/User/Profile"
        data = {
            "app_key": AppKey,
            "uuid": login_ext["data"]["uuid"],
            "token": login_ext["data"]["token"]
        }
        resultData = requests.get(url=url, params=data).json()
        print() or print(resultData)
        assert 200 == resultData["ret"]
        assert 0 == resultData["data"]["err_code"]
        assert "" == resultData["data"]["err_msg"]


if __name__ == '__main__':
    pytest.main()
