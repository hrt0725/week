# -*- coding: utf-8 -*-
# @Time    : 2025/9/24 17:23
# @Author  : Lan
# @File    : test_user_check.py
# @Software: PyCharm
# @Description :
import ddt
import pytest
import requests

from cases.conftest import HostName, login_ext
from config.config import AppKey, getDataPath


@ddt.ddt
class TestUserCheck:

    @ddt.file_data(getDataPath().joinpath("api_user_check.yaml"))
    def test_user_check(self, login_ext, **caseData):
        url = HostName + "/api/App/User/Check"
        caseData["app_key"] = AppKey
        caseData["uuid"] = login_ext["data"]["uuid"]
        caseData["token"] = login_ext["data"]["token"]
        resultData = requests.get(url=url, params=caseData).json()


if __name__ == '__main__':
    pytest.main()
