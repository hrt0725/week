# -*- coding: utf-8 -*-
# @Time    : 2025/9/24 17:06
# @Author  : Lan
# @File    : test_get_users.py
# @Software: PyCharm
# @Description : 
import pytest
import requests

from cases.conftest import HostName
from config.config import AppKey


class TestGetUsers:
    def test_get_users(self):
        url = HostName + "/api/App/User/GetList"
        data = {
            "app_key": AppKey,
            "page": 3,
            "perpage": 20,
            "role": "all",
            "sort_type": 1
        }
        resultData = requests.get(url=url, params=data).json()
        print() or print(resultData)
        for item in resultData["data"]["users"]:
            print(item)
        assert 200 == resultData["ret"]
        assert 0 == resultData["data"]["err_code"]
        assert "" == resultData["data"]["err_msg"]


if __name__ == '__main__':
    pytest.main()
